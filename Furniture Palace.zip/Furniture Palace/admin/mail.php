<?php
include 'session.php';
$username = $_SESSION['user_name'];
$userID = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<?php

require_once 'dbconfig4.php';

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Mail | Furniture Palace</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- DATA TABLES -->
        <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="css/AdminLTE2.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    </head>
<body class="skin-black">
       <!-- header logo: style can be found in header.less -->

       <!-- header logo: style can be found in header.less -->
        <header class="header">
            <a href="index.php" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                Dashboard
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- Messages: style can be found in dropdown.less-->
                        <li class="dropdown messages-menu">
						<?php

							$con = mysqli_connect('localhost', 'root', '', 'flowerieesflora');
							$result = mysqli_query($con,"SELECT * FROM users");
							$num_rows = mysqli_num_rows($result);
				
							?>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-envelope"></i>
                                <span class="label label-success"><?php echo $num_rows; ?></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="header">You have <?php echo $num_rows; ?> mail</li>
                            </ul>
                        </li>
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user">  <?php echo $username;?>  </i>
                                <span><i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header bg-light-blue">
                                     <img src="user.png" class="img-circle" alt="User Image" />
                                    <p>
							
                                        <?php echo $username;?> - Admin User
										
                                    </p>
                                </li>
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-right">
                                        <a href="logout.php?logout=true" class="btn btn-default btn-flat">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
<br><br>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="home.php">
                                <i class="fa fa-dashboard"></i> <span>Home</span>
                            </a>
                        </li>
						<li>
                            <a href="admin.php">
                                <i class="fa fa-user"></i> <span>Admin Users</span>
                            </a>
                        </li>
						<li>
                            <a href="categories.php">
                                <i class="fa fa-list"></i> <span>Categories</span>
                            </a>
                        </li>
						<li>
                            <a href="gallery.php">
                                <i class="fa fa-list"></i> <span>gallery</span>
                            </a>
                        </li>
						<li>
                            <a href="mail.php">
                                <i class="fa fa-list"></i> <span>Mail</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Furniture Palace
                        <small style="font-weight:bold;color:#000000;">Gampaha</small>
                    </h1>
                    <ol class="breadcrumb">
						<a class="btn bg-orange margin"><i class="fa fa-print"></i> Print</a>
						<a class="btn bg-purple margin"><i class="fa fa-file"></i> Excel</a>
						<a class="btn bg-maroon margin"><i class="fa fa-file-text"></i> Pdf</a>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
						<?php

			if(isset($errMSG)){

			?>

            <div class="alert alert-danger">

            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>

            <a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>

            <?php

			}

			else if(isset($successMSG)){

			?>

			<div class="alert alert-success">

              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>

			<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>

			<?php

			}

			?>
                            <div class="box">

                                <div class="box-body table-responsive">
								<h2>
								Customer Messages
								<small style="font-weight:bold;color:#000000;">  View</small>
								</h2>
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Mobile No</th>
												<th>Email Address</th>
												<th>Messages</th>
												<th>Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php

								$stmt = $DB_con->prepare('SELECT id,name,phone,email,message,date FROM mail ORDER BY id DESC');

								$stmt->execute();

								if($stmt->rowCount() > 0)

								{

								while($row=$stmt->fetch(PDO::FETCH_ASSOC))

								{

								extract($row);

								?>
                                            <tr>
                                                <td><?php echo $row['id']; ?></td>
                                                <td><?php echo $row['name']; ?></td>
                                                <td><?php echo $row['phone']; ?></td>
												<td><?php echo $row['email']; ?></td>
												<td><?php echo $row['message']; ?></td>
                                                <td><?php echo $row['date']; ?></td>
												<td><a class="btn btn-primary" href="edit_mail.php?maid=<?php echo $row["id"]; ?>">
												<i class="fa fa-edit"></i>
												</a>
												<a class="btn btn-danger" href="delete_mail.php?maid=<?php echo $row["id"]; ?>">
												<i class="fa fa-times-circle"></i> 
												</a>
												</td>
                                            </tr>
                                <?php } 

								}

								else { 

								?>

								<div class="col-xs-12">

								<div class="alert alert-warning">

								<span class="glyphicon glyphicon-info-sign"></span> &nbsp; No Data Found ...

								<a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>

								</div>

								<?php } ?>
								
                                        </tbody>
                                    </table>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        <!-- jQuery 2.0.2 -->
        <script src="js/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="js/AdminLTE/app.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>

        <!-- page script -->
        <script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>

    </body>
</html>