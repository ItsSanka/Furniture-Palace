<?php

	require_once 'dbconfig4.php';
	
	if(isset($_GET['user_id']))
	{
		
		$stmt_delete = $DB_con->prepare('DELETE FROM users WHERE user_id =:uid');
		$stmt_delete->bindParam(':uid',$_GET['user_id']);
		$stmt_delete->execute();
		
		header("Location: admin.php");
	}

?>