<?php

	require_once 'dbconfig4.php';
	
	if(isset($_GET['gaid']))
	{
		
		$stmt_select = $DB_con->prepare('SELECT image FROM gallery WHERE id =:gaid');
		$stmt_select->execute(array(':gaid'=>$_GET['gaid']));
		$imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
		unlink("img/gallery/".$imgRow['image']);
		
		$stmt_delete = $DB_con->prepare('DELETE FROM gallery WHERE id =:gaid');
		$stmt_delete->bindParam(':gaid',$_GET['gaid']);
		$stmt_delete->execute();
		
		header("Location: gallery.php");
	}

?>