<?php
include 'session.php';
$username = $_SESSION['user_name'];
$userID = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<?php



	error_reporting( ~E_NOTICE );

	

	require_once 'dbconfig4.php';

	

	if(isset($_GET['caid']) && !empty($_GET['caid']))

	{

		$id = $_GET['caid'];

		$stmt_edit = $DB_con->prepare('SELECT id,name,type,description,image,status,add_date FROM category WHERE id =:caid');

		$stmt_edit->execute(array(':caid'=>$id));

		$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);

		extract($edit_row);

	}

	else

	{

		header("Location: categories.php");

	}	

	if(isset($_POST['update']))

	{

		$name = $_POST['name'];

		$type = $_POST['type'];
		
		$description = $_POST['description'];

		$status = $_POST['status'];

		$imgFile = $_FILES['user_image']['name'];
		$tmp_dir = $_FILES['user_image']['tmp_name'];
		$imgSize = $_FILES['user_image']['size'];
		

		if($imgFile)

		{

			$upload_dir = 'img/category/'; // upload directory	

			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension

			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif' ,'docx' , 'pdf' , 'video' , 'mp3'); // valid extensions

			$userpic = rand(1,1000000).".".$imgExt;

			if(in_array($imgExt, $valid_extensions))

			{			

				if($imgSize < 5000000)

				{

					unlink($upload_dir.$edit_row['image']);

				 	move_uploaded_file($tmp_dir,$upload_dir.$userpic);

				}

				else

				{

					$errMSG = "Sorry, your file is too large it should be less then 5MB";

				}

			}

			else

			{

				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		

			}	

		}

		else

		{

			// if no image selected the old image remain as it is.

			$userpic = $edit_row['image']; // old image from database

		}	

		if(!isset($errMSG))

		{

			$stmt = $DB_con->prepare('UPDATE category

									     SET name=:name,
										 
											 type=:type,
											 
											 description=:description,
											 
										     image=:upic,
											 
											 status=:status

								       WHERE id=:caid');

			$stmt->bindParam(':name',$name);
			
			$stmt->bindParam(':type',$type);
			
			$stmt->bindParam(':description',$description);

			$stmt->bindParam(':upic',$userpic);
			
			$stmt->bindParam(':status',$status);

			$stmt->bindParam(':caid',$id);

			if($stmt->execute()){

				$successMSG = "Category Successfully Updated ...";
				echo "<script type='text/javascript'>window.location.href = 'categories.php';</script>";

			}

			else{

				$errMSG = "Sorry Data Could Not Updated !";

			}

		

		}

		

						

	}

	

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Edit Category | Furniture Palace</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- DATA TABLES -->
        <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="css/AdminLTE2.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    </head>
    <body class="skin-black">
       <!-- header logo: style can be found in header.less -->

       <!-- header logo: style can be found in header.less -->
        <header class="header">
            <a href="index.php" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                Dashboard
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- Messages: style can be found in dropdown.less-->
                        <li class="dropdown messages-menu">
						<?php

							$con = mysqli_connect('localhost', 'root', '', 'flowerieesflora');
							$result = mysqli_query($con,"SELECT * FROM users");
							$num_rows = mysqli_num_rows($result);
				
							?>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-envelope"></i>
                                <span class="label label-success"><?php echo $num_rows; ?></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="header">You have <?php echo $num_rows; ?> mail</li>
                            </ul>
                        </li>
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user">  <?php echo $username;?>  </i>
                                <span><i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header bg-light-blue">
                                     <img src="user.png" class="img-circle" alt="User Image" />
                                    <p>
							
                                        <?php echo $username;?> - Admin User
										
                                    </p>
                                </li>
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-right">
                                        <a href="logout.php?logout=true" class="btn btn-default btn-flat">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
<br><br>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="home.php">
                                <i class="fa fa-dashboard"></i> <span>Home</span>
                            </a>
                        </li>
						<li>
                            <a href="admin.php">
                                <i class="fa fa-user"></i> <span>Admin Users</span>
                            </a>
                        </li>
						<li>
                            <a href="categories.php">
                                <i class="fa fa-list"></i> <span>Categories</span>
                            </a>
                        </li>
						<li>
                            <a href="gallery.php">
                                <i class="fa fa-list"></i> <span>gallery</span>
                            </a>
                        </li>
						<li>
                            <a href="mail.php">
                                <i class="fa fa-list"></i> <span>Mail</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Furniture Palace
                        <small style="font-weight:bold;color:#000000;">Gampaha</small>
                    </h1>
                    <ol class="breadcrumb">
						<a class="btn bg-orange margin"><i class="fa fa-print"></i> Print</a>
						<a class="btn bg-purple margin"><i class="fa fa-file"></i> Excel</a>
						<a class="btn bg-maroon margin"><i class="fa fa-file-text"></i> Pdf</a>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
						<?php

	if(isset($errMSG)){

			?>

            <div class="alert alert-danger">

            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>

            <a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>

            <?php

	}

	else if(isset($successMSG)){

		?>

        <div class="alert alert-success">

              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>

        <a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>

        <?php

	}

	?>   

						<!-- Main content -->
						<div class="row">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <div class="box-header">
                                    <h3 class="box-title">Edit Category</h3>
                                </div><!-- /.box-header -->
                                <!-- form start -->
                            <form method="post" enctype="multipart/form-data">
							<div class="box-body">
							<div class="form-group">
                            <label for="exampleInputPassword1">Category Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter Your Category Name" value="<?php echo $name; ?>" required>
                            </div>
							<div class="form-group">
                            <label for="exampleInputPassword1">Type</label>
                            <select name="type" class="form-control" value="<?php echo $type; ?>">
                            <option>For Sale</option>
                            <option>For Rent</option>
							</select>
                            </div>
							<div class="form-group">
                            <label for="exampleInputPassword1">Description</label>
                            <textarea type="text" name="description" class="form-control" placeholder="Enter Your Description"><?php echo $description; ?></textarea>
                            </div>
							<div class="form-group">
							<img src="img/category/<?php echo $image; ?>" width="200px" height="150px" style="border:1px solid #333333;">
							<br><br>
                            <label for="exampleInputFile">Image</label>
                            <input type="file" name="user_image"  multiple>
							<em style="font-weight:bold;color:#FF0000;">Plz Before To Upload Convert Your Image (400px * 400px)</em>
							</div>
							<div class="form-group">
                            <label for="exampleInputPassword1">Publish Or Unpublish</label>
                            <select name="status" class="form-control" value="<?php echo $status; ?>">
                            <option>Publish</option>
                            <option>Unpublish</option>
							</select>
                            </div>
							<div class="box-footer">

                            <button type="submit" class="btn btn-danger" href="category.php"><i class="fa fa-times"></i> Close</button>

                            <button type="submit" name="update" class="btn btn-primary pull-left"><i class="fa fa-edit"></i> Update</button>
							</div>
							</form>
                            </div><!-- /.box -->
							</div>
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        <!-- jQuery 2.0.2 -->
        <script src="js/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="js/AdminLTE/app.js" type="text/javascript"></script>
		<script src="js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
		<script type="text/javascript">
            $(function() {
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace('editor1');
                //bootstrap WYSIHTML5 - text editor
                $(".textarea").wysihtml5();
            });
        </script>
        <!-- page script -->
        <script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>

    </body>
</html>