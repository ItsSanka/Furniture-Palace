<?php

	require_once 'dbconfig4.php';
	
	if(isset($_GET['maid']))
	{

		$stmt_delete = $DB_con->prepare('DELETE FROM mail WHERE id =:maid');
		$stmt_delete->bindParam(':maid',$_GET['maid']);
		$stmt_delete->execute();
		
		header("Location: mail.php");
	}

?>