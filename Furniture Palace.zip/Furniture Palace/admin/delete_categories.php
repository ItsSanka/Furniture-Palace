<?php

	require_once 'dbconfig4.php';
	
	if(isset($_GET['caid']))
	{
		
		$stmt_select = $DB_con->prepare('SELECT image FROM category WHERE id =:caid');
		$stmt_select->execute(array(':caid'=>$_GET['caid']));
		$imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
		unlink("img/category/".$imgRow['image']);
		
		$stmt_delete = $DB_con->prepare('DELETE FROM category WHERE id =:caid');
		$stmt_delete->bindParam(':caid',$_GET['caid']);
		$stmt_delete->execute();
		
		header("Location: categories.php");
	}

?>