<?php
include 'session.php';
$username = $_SESSION['user_name'];
$userID = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<?php

	require_once 'dbconfig4.php';
	
	if(isset($_GET['adid']) && !empty($_GET['adid']))
	{
		$id = $_GET['adid'];
		$stmt_edit = $DB_con->prepare('SELECT user_name, user_email, user_pass FROM users WHERE user_id =:uaid');
		$stmt_edit->execute(array(':uaid'=>$id));
		$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
		extract($edit_row);
	}
	else
	{
		header("Location: admin.php");
	}	
	
	if(isset($_POST['update']))
	{
	
	
	$uname =$_POST['user_name'];
	$uemail =$_POST['user_email'];
	$new_password =$_POST['user_pass'];
	//$new_password = password_hash($upassword, PASSWORD_DEFAULT);
		
		// if no error occured, continue ....
		if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('UPDATE users 
									     SET user_name=:uname, 
										     user_email=:uemail,
											 user_pass=:upass 
								       WHERE user_id=:uaid');
			$stmt->bindParam(':uname',$uname);
			$stmt->bindParam(':uemail',$uemail);
			$stmt->bindParam(':upass',$new_password);
			$stmt->bindParam(':uaid',$id);
				
			if($stmt->execute()){
				$successMSG = "Admin Registration Succefully Updated ...";
				echo "<script type='text/javascript'>window.location.href = 'admin.php';</script>";
			}
			else{
				$errMSG = "Sorry Data Could Not Updated !";
			}
		
		}
		
						
	}
	
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Edit Admin User | Furniture Palace</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- DATA TABLES -->
        <link href="css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="css/AdminLTE2.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    </head>
    <body class="skin-black">
       <!-- header logo: style can be found in header.less -->

       <!-- header logo: style can be found in header.less -->
        <header class="header">
            <a href="index.php" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                Dashboard
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- Messages: style can be found in dropdown.less-->
                        <li class="dropdown messages-menu">
						<?php

							$con = mysqli_connect('localhost', 'root', '', 'flowerieesflora');
							$result = mysqli_query($con,"SELECT * FROM users");
							$num_rows = mysqli_num_rows($result);
				
							?>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-envelope"></i>
                                <span class="label label-success"><?php echo $num_rows; ?></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="header">You have <?php echo $num_rows; ?> mail</li>
                            </ul>
                        </li>
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user">  <?php echo $username;?>  </i>
                                <span><i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header bg-light-blue">
                                     <img src="user.png" class="img-circle" alt="User Image" />
                                    <p>
							
                                        <?php echo $username;?> - Admin User
										
                                    </p>
                                </li>
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-right">
                                        <a href="logout.php?logout=true" class="btn btn-default btn-flat">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
<br><br>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="home.php">
                                <i class="fa fa-dashboard"></i> <span>Home</span>
                            </a>
                        </li>
						<li>
                            <a href="admin.php">
                                <i class="fa fa-user"></i> <span>Admin Users</span>
                            </a>
                        </li>
						<li>
                            <a href="categories.php">
                                <i class="fa fa-list"></i> <span>Categories</span>
                            </a>
                        </li>
						<li>
                            <a href="gallery.php">
                                <i class="fa fa-list"></i> <span>gallery</span>
                            </a>
                        </li>
						<li>
                            <a href="mail.php">
                                <i class="fa fa-list"></i> <span>Mail</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Furniture Palace
                        <small style="font-weight:bold;color:#000000;">Gampaha</small>
                    </h1>
                </section>

                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
						<?php
	if(isset($errMSG)){
			?>
            <div class="alert alert-danger">
            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            <a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>
            <?php
	}
	else if(isset($successMSG)){
		?>
        <div class="alert alert-success">
              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
        <a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a></div>
        <?php
	}
	?>  
		
						<!-- Main content -->
						<div class="row">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <div class="box-header">
                                    <h3 class="box-title">Edit Admin User</h3>
                                </div><!-- /.box-header -->
                                <!-- form start -->
                            <form method="post" enctype="multipart/form-data">
							<div class="box-body">
                            <div class="form-group">
									<label for="exampleInputPassword1">User Name</label>
									<input type="text" class="form-control" name="user_name" placeholder="Enter Your User Name" value="<?php echo $user_name; ?>" required>
                            </div>
                            <div class="form-group">
									<label for="exampleInputPassword1">User Email</label>
									<input type="email" class="form-control" name="user_email" placeholder="Enter Your User Email" value="<?php echo $user_email; ?>" required>
                            </div>
							<div class="form-group">
									<label for="exampleInputPassword1">User Password</label>
									<input type="password" class="form-control" name="user_pass" placeholder="Enter Your User Password" value="<?php echo $user_pass; ?>" required>
                            </div>
							<div class="box-footer">

                            <button type="submit" class="btn btn-danger" href="admin.php"><i class="fa fa-times"></i> Close</button>

                            <button type="submit" name="update" class="btn btn-primary pull-left"><i class="fa fa-edit"></i> Update</button>
							</div>
							</form>
                            </div><!-- /.box -->
							</div>
                        </div>
                    </div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        <!-- jQuery 2.0.2 -->
        <script src="js/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <!-- DATA TABES SCRIPT -->
        <script src="js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="js/AdminLTE/app.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>

        <!-- page script -->
        <script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>

    </body>
</html>