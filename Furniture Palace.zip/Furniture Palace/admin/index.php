<?php
	include 'conn.php';
	session_start();

	if(isset($_SESSION['user_id'])){

		header('location:home.php');
	}

	if(isset($_POST['log'])){

		$user = $_POST['username'];
		$pass =  $_POST['pass'];

		$sql = "SELECT * FROM users where user_name = '$user' and user_pass = '$pass'";
		$result = $conn->query($sql);

		if($result-> num_rows > 0){
			while($row= $result->fetch_assoc()){
				$_SESSION['user_id'] = $row['user_id'];
				$_SESSION['user_name'] = $row['user_name'];	
			}
			?>
			<script> alert('Welcome <?php echo $_SESSION['user_name']?>'); </script>
			<script>window.location='home.php';</script>
			<?php

		
			}else{
				echo "<center><p style=color:red;>Invalid username or password</p></center>";

		}
		$conn->close();
	}
?>
<!DOCTYPE html>
<html class="bg-yellow">
    <head>
        <meta charset="UTF-8">
        <title>Furniture Palace | Log in</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
    </head>
    <body class="bg-yellow">
        <div class="form-box" id="login-box" class="bg-yellow">
            <div class="header" style="background-color:#0d95e4;font-weight:bold;font-size:22px;">Dashboard | Furniture Palace</div>
                <div class="body bg-gray">
		<form class="form-signin" action="index.php" method="post" id="login-form">
        <div class="form-group">
        <input type="text" class="form-control" name="username" placeholder="Username or E mail ID" required />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group">
        <input type="password" class="form-control" name="pass" placeholder="Your Password" />
        </div>
       
     	<hr />
        
        <div class="form-group">
            <input type="submit" name="log" class="btn btn-default" value="LOG IN"/>
        </div>  

      </form>
<!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>        

    </body>
</html>
