<!DOCTYPE html>
<html lang="en">
<?php

require_once 'admin/dbconfig4.php'; 

?>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>Gallery | Furniture palace | Gampaha | Leader In The Furniture Field</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="Gampaha Furniture,Gampaha,Furniture palace,wedding decorations badulla,Adornment By Flowers,Wedding Flora badulla ,wedding flora,flora in badulla,wedding palanning in sri lanka,wedding decorations,decorations badulla,deco badulla,flora badulla,wedding decoration in badulla">
<meta name="description" content="Floweriees Flora is Best Uncommon Wedding Design Unity and wedding decorations,home coming,lighting,theater,Occasions in Badulla">
<meta name="author" content="Floweriees Flora | Badulla">
<link rel="alternate" type="application/rss+xml" title="Gallery | Floweriees Flora | Badulla | Wedding Decorations | Adornment By Flowers" href="http://www.flowerieesflora.com/gallery.php"/>
<link rel="alternate" type="application/rss+xml" title="Gallery | Floweriees Flora | Badulla | Wedding Decorations | Adornment By Flowers" href="http://www.flowerieesflora.com/gallery.php"/>
<link rel="alternate" type="application/rss+xml" title="Gallery | Floweriees Flora | Badulla| Wedding Decorations | Adornment By Flowers" href="http://www.flowerieesflora.com/gallery.php"/>
<link rel="alternate" type="application/rss+xml" title="Gallery | Floweriees Flora | Badulla | Wedding Decorations | AdornmentBy Flowers" href="http://www.flowerieesflora.com/gallery.php"/>
<meta name="generator" content="Gallery | Floweriees Flora | Badulla | Wedding Decorations | AdornmentBy Flowers"/>
<link rel="canonical" href="http://www.flowerieesflora.com/gallery.php"/>
<link rel='shortlink' href='http://flowerieesflora.com/gallery.php'/>

  
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/reality-icon.css">
<link rel="stylesheet" type="text/css" href="css/bootsnav.css">
<link rel="stylesheet" type="text/css" href="css/animate.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
<link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
<link rel="stylesheet" type="text/css" href="css/settings.css">
<link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
<link rel="stylesheet" type="text/css" href="css/search.css">
<link rel="stylesheet" type="text/css" href="css/style.css">

<link rel="apple-touch-icon" sizes="57x57" href="favi/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favi/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favi/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favi/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favi/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favi/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favi/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favi/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favi/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="favi/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favi/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favi/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favi/favicon-16x16.png">
<link rel="manifest" href="favi/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="favi/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
</head>
<body>


<!--Loader-->
<div class="loader">
  <div class="span">
    <img src="favi/android-icon-192x192.png" alt="" class="location_indicator" width="160" height="140"/>
  </div>
</div>
 <!--Loader--> 


<!--Header-->
<header class="layout_dark">
  <div class="topbar">
    <div class="container">
      <div class="row">
        <div class="col-md-5">
          <p>We are Best in furniturise Gampaha With 30 years of Experience.</p>
        </div>

      </div>
    </div>
  </div>
  <div class="header-upper" style="background-color:#000000;color:#ffffff;">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-12">
          <div class="logo"><a href="index2.html"><img alt="" src="images/logo7.png" width="200" height="100"></a></div>
        </div>
        <!--Info Box-->
        <div class="col-md-9 col-sm-12 right">
          <div class="info-box first">
            <div class="icons"><i class="icon-telephone114"></i></div>
            <ul>
              <li><strong style="font-weight;bold;color:#ffd119;">Phone Number</strong></li>
              <li>055-4545794 / 071-7197165 / 071-1612170</li>
            </ul>
          </div>
          <div class="info-box">
            <div class="icons"><i class="icon-icons74"></i></div>
            <ul>
              <li><strong style="font-weight;bold;color:#ffd119;">Address</strong></li>
              <li>Main Road,Gampaha</li>
            </ul>
          </div>
          <div class="info-box">
            <div class="icons"><i class="icon-icons142"></i></div>
            <ul>
              <li><strong style="font-weight:bold;color:#ffd119;">Email Address</strong></li>
              <li><a href="javascript:void(0)">info@furniturepalace.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-default navbar-sticky bootsnav">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="attr-nav">
            <a href="#" class="btn-touch uppercase" style="font-weight:bold;">ගෘහ භාණ්ඩ ක්ෂේත්‍රයේ ප්‍රමුඛයා</a>
          </div>
          <div class="attr-nav ">
            <ul class="social_share  clearfix">
              <li><a href="javascript:void(0)" class="facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="javascript:void(0)" class="twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a class="google" href="javascript:void(0)"><i class="icon-google4"></i></a></li>
            </ul>
          </div>
          <!-- Start Header Navigation -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand sticky_logo" href="index2.html"><img src="images/logo-white2.png" class="logo" alt="" width="80" height="40"></a>
          </div>
          <!-- End Header Navigation -->
          <div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav" data-in="fadeIn" data-out="fadeOut">
              <li class="dropdown">
                <a href="index.php">Home</a>
              </li>
              <li>
                <a href="about.php">About</a>
              </li>
              <li class="dropdown">
                <a href="#." class="dropdown-toggle" data-toggle="dropdown">Our Category</a>
                <ul class="dropdown-menu">
                  <li class="dropdown">
          <?php

                $stmt = $DB_con->prepare('SELECT id,name FROM category ORDER BY id DESC');

                $stmt->execute();

                if($stmt->rowCount() > 0)

                {

                while($row=$stmt->fetch(PDO::FETCH_ASSOC))

                {

                extract($row);

                ?>
                <a href="category.php?category=<?php echo $row['name'];  ?>"><?php echo $row['name']; ?></a>
                                <?php 

                }
                
                }

                ?>
                  </li>
                </ul>
              </li>
        <li><a href="gallery.php" class="dropdown active">Gallery</a></li>
              <li><a href="contact.php">Contact Us</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>
</header>
<!--Header Ends-->



<!-- Page Banner Start-->
<section class="page-banner padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h1 class="text-uppercase">Furniture Gallery</h1>
        <ol class="breadcrumb text-center">
          <li><a href="index.php">Home</a></li>
          <li class="active">Gallery</li>
        </ol>
      </div>
    </div>
  </div>
</section>
<!-- Page Banner End -->



<!-- Gallery -->

<section id="property" class="padding">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12 text-center">
        <h2 class="uppercase">Item Gallery</h2>
        <p class="heading_space">We have Wonderful Crafted Items and View a list of Featured Gallery.</p>
      </div>
    </div>
    <div class="clearfix">
      
    </div>
    <div id="photo-gallery" class="cbp">
  <?php
  $con = mysqli_connect("localhost", "root", "", "flowerieesflora");
$sql = "SELECT * from category";
$sql2 = "select * FROM gallery order by id ASC";
$result = mysqli_query($con,$sql2);

$start=0;
$limit=8;

if(isset($_GET['page_no']))
{
  $id=$_GET['page_no'];
  $start=($id-1)*$limit;
}

while($query2 = mysqli_fetch_array($result))

{
?>
    <div class="cbp-item <?php echo $query2["categoy_name"] ?>">
        <a href="admin/img/gallery/<?php echo $query2["image"] ?>" class="cbp-lightbox"><img src="admin/img/gallery/<?php echo $query2["image"] ?>" alt="" style="width:400px;height:300px;"></a>
    </div>
<?php     
}
?>  
      
    </div>
    <div class="col-sm-12 text-center">
       <?php
echo "<div class='pagination'>";
$id='';
$sql = "select * from gallery order by id ASC";
$result = mysqli_query($con,$sql);

$rows=mysqli_num_rows($result);
$total=ceil($rows/$limit);
echo "<ul class='pagination theme-colored xs-pull-center m-0'  style='font-weight:bold;'>";
echo "<li> <a href='#' aria-label='Previous' style='font-weight:bold;background-color:#000000;color:#ffffff;'> <span aria-hidden='true'>«</span> </a> </li>";
    for($i=1;$i<=$total;$i++)
    {
      if($i==$id) { echo "<li class='active'><a href='#' style='font-weight:bold;background-color:#ffffff;color:#000000;'>".$i."</a></li>"; }

      else { echo "<li><a href='?page_no=".$i."' style='font-weight:bold;background-color:#000000;color:#ffffff;'>".$i."</a></li>"; }
    }
echo "<li> <a href='#' aria-label='Next' style='font-weight:bold;background-color:#000000;color:#ffffff;'> <span aria-hidden='true'>»</span> </a> </li>";
echo "</ul>";
echo "</div>";

?>
    </div>
  </div>
</section>
<!-- Gallery Ends -->


<!--Footer-->
<footer class="padding_top" style="background-color:#0d70c5;">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <a href="javascript:void(0)" class="logo bottom30"><img src="images/logo-white2.png" alt="logo" width="200" height="100"></a>
          <p class="bottom15" style="font-weight:bold;color:#ffffff;text-align:justify;">We are proud to say that we can provide 15 years warranty for Treated Rubber wood.
          </p>
          <ul class="social_share">
            <li><a href="javascript:void(0)" class="facebook"><i class="icon-facebook-1"></i></a></li>
            <li><a href="javascript:void(0)" class="twitter"><i class="icon-twitter-1"></i></a></li>
            <li><a href="javascript:void(0)" class="google"><i class="icon-google4"></i></a></li>
            <li><a href="javascript:void(0)" class="linkden"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="javascript:void(0)" class="vimo"><i class="icon-vimeo3"></i></a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 class="bottom30" style="font-weight:bold;color:#ffd119;">Find Location</h4>
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d852662.5821227395!2d79.84654465192558!3d6.90162326014638!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7faaf9ddaee10f1e!2sGamini%20Furniture%20Palace!5e0!3m2!1sen!2slk!4v1594063165105!5m2!1sen!2slk" width="320" height="240" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
    </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 style="font-weight:bold;color:#ffd119;">Facebook Fan Page</h4><br>
          <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fweb.facebook.com%2FFlowerriees-flora-1106483016155896%2F&tabs=timeline&width=320&height=240&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=343337676171010" width="320" height="240" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 class="bottom30" style="font-weight:bold;color:#ffd119;">Get in Touch</h4>
          <ul class="getin_touch">
            <li style="font-weight:bold;color:#ffffff;"><i class="icon-telephone114"></i>055-4545794</li>
      <li style="font-weight:bold;color:#ffffff;"><i class="icon-telephone114"></i>071-7197165</li>
      <li style="font-weight:bold;color:#ffffff;"><i class="icon-telephone114"></i>071-1612170</li>
            <li style="font-weight:bold;color:#ffffff;"><a href="javascript:void(0)"><i class="icon-mail-envelope-open"></i>info@furniturePalace.com</a></li>
            <li style="font-weight:bold;color:#ffffff;"><a href="javascript:void(0)"><i class="icon-global"></i>www.furniturePalace.com</a></li>
            <li style="font-weight:bold;color:#ffffff;"><i class="icon-icons74"></i>Main Road,Gampaha</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<!--CopyRight-->
<div class="copyright">
  <div class="copyright_inner">
    <div class="container">
      <div class="row">
        <div class="col-md-7">
          <p style="font-weight:bold;color:#ffffff;">Copyright &copy; 2020 <span>Furniture Palace | Gampaha</span>. All rights reserved.</p>
        </div>
        <div class="col-md-5 text-right">
          <p style="font-weight:bold;color:#ffffff;">Develop by <a href="">SDM Designer</a></p>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="js/jquery-2.1.4.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.appear.js"></script>
<script src="js/jquery-countTo.js"></script>
<script src="js/bootsnav.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/range-Slider.min.js"></script>
<script src="js/owl.carousel.min.js"></script> 
<script src="js/selectbox-0.2.min.js"></script>
<script src="js/zelect.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery.themepunch.tools.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/revolution.extension.layeranimation.min.js"></script>
<script src="js/revolution.extension.navigation.min.js"></script>
<script src="js/revolution.extension.parallax.min.js"></script>
<script src="js/revolution.extension.slideanims.min.js"></script>
<script src="js/revolution.extension.video.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/functions.js"></script>
</body>
</html>
