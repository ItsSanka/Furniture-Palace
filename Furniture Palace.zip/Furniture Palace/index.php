<!DOCTYPE html>
<html lang="en">
<?php

require_once 'admin/dbconfig4.php'; 

?>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>About | Furniture palace | Gampaha | Leader In The Furniture Field</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="badulla flora,badulla,floweriees flora,wedding decorations badulla,Adornment By Flowers,Wedding Flora badulla ,wedding flora,flora in badulla,wedding palanning in sri lanka,wedding decorations,decorations badulla,deco badulla,flora badulla,wedding decoration in badulla">
<meta name="description" content="Floweriees Flora is Best Uncommon Wedding Design Unity and wedding decorations,home coming,lighting,theater,Occasions in Badulla">
<meta name="author" content="Floweriees Flora | Badulla | Wedding Decorations | Adornment By Flowers">
<link rel="alternate" type="application/rss+xml" title="Floweriees Flora | Badulla | Wedding Decorations | Adornment By Flowers" href="http://www.flowerieesflora.com" />
<link rel="alternate" type="application/rss+xml" title="Floweriees Flora | Badulla | Wedding Decorations | Adornment By Flowers" href="http://www.flowerieesflora.com" />
<link rel="alternate" type="application/rss+xml" title="Floweriees Flora | Badulla| Wedding Decorations | Adornment By Flowers" href="http://www.flowerieesflora.com" />
<link rel="alternate" type="application/rss+xml" title="Floweriees Flora | Badulla | Wedding Decorations | AdornmentBy Flowers" href="http://www.flowerieesflora.com"/>
<meta name="generator" content="Floweriees Flora | Badulla | Wedding Decorations | AdornmentBy Flowers"/>
<link rel="canonical" href="http://www.flowerieesflora.com/"/>
<link rel='shortlink' href='http://flowerieesflora.com/'/>

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/reality-icon.css">
<link rel="stylesheet" type="text/css" href="css/bootsnav.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="css/settings.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/range-Slider.min.css">
<link rel="stylesheet" type="text/css" href="css/search.css">

<link rel="apple-touch-icon" sizes="57x57" href="favi/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="favi/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="favi/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="favi/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="favi/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="favi/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="favi/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="favi/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="favi/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="favi/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="favi/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="favi/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="favi/favicon-16x16.png">
<link rel="manifest" href="favi/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="favi/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
</head>
<body>

<!--Loader-->
 <div class="loader">
  <div class="span">
    <img src="favi/android-icon-192x192.png" alt="" class="location_indicator" sizes="32x32" width="160" height="140"/>
  </div>
</div>
 <!--Loader  -->
 
<!--Header-->
<header class="layout_dark">
  <div class="topbar">
    <div class="container">
      <div class="row">
        <div class="col-md-5">
          <p>We are Best in furniturise Gampaha With 30 years of Experience.</p>
        </div>

      </div>
    </div>
  </div>
  <div class="header-upper" style="background-color:#000000;color:#ffffff;">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-12">
          <div class="logo"><a href="index.php"><img alt="" src="images/logo7.png" width="200" height="100"></a></div>
        </div>
        <!--Info Box-->
        <div class="col-md-9 col-sm-12 right">
          <div class="info-box first">
            <div class="icons"><i class="icon-telephone114"></i></div>
            <ul>
              <li><strong style="font-weight;bold;color:#ffd119;">Phone Number</strong></li>
              <li>055-4545794 / 071-7197165 / 071-1612170</li>
            </ul>
          </div>
          <div class="info-box">
            <div class="icons"><i class="icon-icons74"></i></div>
            <ul>
              <li><strong style="font-weight;bold;color:#ffd119;">Address</strong></li>
              <li> Main Road,Gampaha </li>
            </ul>
          </div>
          <div class="info-box">
            <div class="icons"><i class="icon-icons142"></i></div>
            <ul>
              <li><strong style="font-weight:bold;color:#ffd119;">Email Address</strong></li>
              <li><a href="javascript:void(0)">info@furniturepalace.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-default navbar-sticky bootsnav">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="attr-nav">
            <a href="#" class="btn-touch uppercase" style="font-weight:bold;">
ගෘහ භාණ්ඩ ක්ෂේත්‍රයේ ප්‍රමුඛයා</a>
          </div>
          <div class="attr-nav ">
            <ul class="social_share  clearfix">
              <li><a href="javascript:void(0)" class="facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="javascript:void(0)" class="twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a class="google" href="javascript:void(0)"><i class="icon-google4"></i></a></li>
            </ul>
          </div>
          <!-- Start Header Navigation -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand sticky_logo" href="index2.html"><img src="images/logo-white2.png" class="logo" alt="" width="80" height="40"></a>
          </div>
          <!-- End Header Navigation -->
          <div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav" data-in="fadeIn" data-out="fadeOut">
              <li class="dropdown active">
                <a href="index.php">Home</a>
              </li>
              <li>
                <a href="about.php">About</a>
              </li>
              <li class="dropdown">
                <a href="#." class="dropdown-toggle active" data-toggle="dropdown">Our Category</a>
                <ul class="dropdown-menu">
                  <li class="dropdown">
          <?php

                $stmt = $DB_con->prepare('SELECT id,name FROM category ORDER BY id DESC');

                $stmt->execute();

                if($stmt->rowCount() > 0)

                {

                while($row=$stmt->fetch(PDO::FETCH_ASSOC))

                {

                extract($row);

                ?>
                <a href="category.php?category=<?php echo $row['name'];  ?>"><?php echo $row['name']; ?></a>
                                <?php 

                }
                
                }

                ?>
                  </li>
                </ul>
              </li>
        <li>
                <a href="gallery.php">Gallery</a>
              </li>
              <li><a href="contact.php">Contact Us</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>
</header>
<!--Header Ends-->


<!--Slider-->
 <div class="rev_slider_wrapper">
   <div id="rev_slider" class="rev_slider"  data-version="5.0">
      <ul>
         <li data-transition="fade">
            <img src="images/banner5.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
            <div class="slider-caption tp-caption tp-resizeme"
               data-x="['left','left','center','center']" data-hoffset="['0','0','0','15']" 
               data-y="['center','center','center','center']" data-voffset="['0','0','0','0']" 
               data-responsive_offset="on"
               data-visibility="['on','on','off','off']"  
               data-start="1300"
               data-transition="fade"
               data-transform_idle="o:1;"
               data-transform_in="x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
               data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
               data-mask_in="x:0px;y:0px;s:inherit;e:inherit;">
               <h4 class="bg_blue default_clr">Welcome</h4>
               <div class="bg_white text-left">
                  <h2 style="font-weight:bold;">Furniture Palace | Gampaha</h2>
                  <a href="javascript:void(0)" class="btn-more">
                  <i><img src="images/arrowl.png" alt="arrow"></i><br>
                  <span class="btn-blue">More Details</span>
                  <i><img src="images/arrowr.png" alt="arrow"></i>
                  </a>
               </div>

            </div>
         </li>
         <li data-transition="slideleft">
            <img src="images/banner6.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
            <div class="slider-caption tp-caption tp-resizeme"
               data-x="['right','right','center','center']" data-hoffset="['0','0','0','15']" 
               data-y="['center','center','center','center']" data-voffset="['0','0','0','0']" 
               data-responsive_offset="on" 
               data-visibility="['on','on','off','off']" 
               data-start="1300"
               data-transform_idle="o:1;"
               data-transform_in="x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
               data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
               data-mask_in="x:0px;y:0px;s:inherit;e:inherit;">
               <h4 class="bg_blue default_clr">Join With Us</h4>
               <div class="bg_white text-left">
                  <h2 style="font-weight:bold;">Custom Designs</h2>
                  <a href="javascript:void(0)" class="btn-more">
                  <i><img src="images/arrowl.png" alt="arrow"></i><br>
                  <span class="btn-blue">More Details</span>
                  <i><img src="images/arrowr.png" alt="arrow"></i>
                  </a>
               </div>

            </div>
         </li>
         <li data-transition="slideleft">
            <img src="images/banner7.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
            <div class="slider-caption tp-caption tp-resizeme"
               data-x="['right','right','center','center']" data-hoffset="['0','0','0','15']" 
               data-y="['center','center','center','center']" data-voffset="['0','0','0','0']" 
               data-responsive_offset="on"
               data-visibility="['on','on','off','off']" 
               data-start="1300"
               data-transform_idle="o:1;"
               data-transform_in="x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 
               data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
               data-mask_in="x:0px;y:0px;s:inherit;e:inherit;">
               <h4 class="bg_blue default_clr">Furniture Palace| Gampaha</h4>
               <div class="bg_white text-left">
                  <h2 style="font-weight:bold;">Dowry Packages</h2>
                  <a href="javascript:void(0)" class="btn-more">
                  <i><img src="images/arrowl.png" alt="arrow"></i><br>
                  <span class="btn-blue">More Details</span>
                  <i><img src="images/arrowr.png" alt="arrow"></i>
                  </a>
               </div>
            </div>

            </div>
         </li>
      </ul>
   </div>
</div>

<!--Featured Property-->
<section id="feature_property" class="padding">
  <div class="container feature3">
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <h2 class="uppercase">About Furniture Palace</h2>
        <h4 class="bottom30">Main road,Gampaha</h4>
        <p class="bottom30" style="font-weight:bold;text-align:justify;">Presently we are providing our products to small scale to large scale enterprises, other than house hold furniture. We are capable of manufacturing customized and new designs on your requirements. We are ready to come to your premises and have your idea to design unique furniture for you.</p>
        <div class="row">
          <div class="col-md-6 col-sm-6">
            <ul class="feature_list">
              <li style="font-weight:bold;">Bed room furniture</li>
              <li style="font-weight:bold;">Living room furniture</li>
            </ul>
          </div>

          <div class="col-md-6 col-sm-6">
            <ul class="feature_list">
              <li style="font-weight:bold;">Dining room furniture</li>
              <li style="font-weight:bold;">Office furniture</li>
            </ul>
          </div>
      <div class="col-md-6 col-sm-6">
            <ul class="feature_list">
              <li style="font-weight:bold;">Antique furniture</li>
              <li style="font-weight:bold;">Wood Carvings Arts</li>
            </ul>
          </div>

          <div class="col-md-6 col-sm-6">
            <ul class="feature_list">
              <li style="font-weight:bold;">Baby room furniture</li>
              <li style="font-weight:bold;">Other items</li>
            </ul>
          </div>
        </div>
        <a href="about.php" class="uppercase btn-blue border_radius space30">view about</a>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="feature_main">
          <img src="images/furniture(3).gif" alt="featured" class="img-responsive" width="564" height="354">
          <div class="bottom clearfix">
            <span class="pull-left">Crafted Furniture</span>
            <h4 class="pull-right">Furniture Palace - <small>Gampaha</small></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--Featured Property Ends-->

<!-- Latest Property -->
<section id="property" class="padding index2 bg_light">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-10">
        <h2 class="uppercase">Our Furniture Categories</h2>
        <p class="heading_space">Best and Experience Furniture Making & Leader In The Furniture Field Gampaha. 
        </p>
      </div>
    </div>
    <div class="row">
      <div class="three-item owl-carousel">
<?php
$con = mysqli_connect("localhost", "root", "", "flowerieesflora");
$sql = "SELECT * from category";
$result = mysqli_query($con,$sql);
while($query2 = mysqli_fetch_array($result)){ ?>

  <div class="item">
          <div class="property_item">
            <div class="property_head default_clr text-center">
              <img src="images/favruite.png" alt="property" class="start_tag">
              <h3 class="captlize"><a href="#"><?php echo $query2["name"] ?></a></h3>
            </div>
            <div class="image">
              <a href="#"> <img src="admin/img/category/<?php echo $query2["image"] ?>" alt="latest property" class="img-responsive" style="width:400px;height:300px;"></a>
              <div class="price lighter clearfix"> 
                <span class="tag" style="font-weight:bold;color:#000000;"><?php echo $query2["type"] ?></span>
              </div>
            </div>
            <div class="proerty_content">
              <div class="proerty_text">
                <p style="font-weight:bold;color:#000000;text-align:justify;"><?php echo $query2["description"] ?></p>
              </div>
              <div class="favroute clearfix">
                <a href="category.php?category=<?php echo $query2['name'];  ?>"><p class="pull-md-center" style="font-weight:bold;color:#000000;">View More</p></a>
              </div>
            </div>
          </div>
        </div>
    
<?php }
//mysqli_close($con);
?>       
      </div>
    </div>
  </div>
</section>
<!-- Latest Property Ends -->

<!-- Latest Property -->


<!--Gallery ends-->

<!--Footer-->
<footer class="padding_top" style="background-color:#0d70c5;">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <a href="javascript:void(0)" class="logo bottom30"><img src="images/logo-white2.png" alt="logo" width="200" height="100"></a>
          <p class="bottom15" style="font-weight:bold;color:#ffffff;text-align:justify;">We are proud to say that we can provide 15 years warranty for Treated Rubber wood.
          </p>
          <ul class="social_share">
            <li><a href="javascript:void(0)" class="facebook"><i class="icon-facebook-1"></i></a></li>
            <li><a href="javascript:void(0)" class="twitter"><i class="icon-twitter-1"></i></a></li>
            <li><a href="javascript:void(0)" class="google"><i class="icon-google4"></i></a></li>
            <li><a href="javascript:void(0)" class="linkden"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="javascript:void(0)" class="vimo"><i class="icon-vimeo3"></i></a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 class="bottom30" style="font-weight:bold;color:#ffd119;">Find Location</h4>
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d852662.5821227395!2d79.84654465192558!3d6.90162326014638!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7faaf9ddaee10f1e!2sGamini%20Furniture%20Palace!5e0!3m2!1sen!2slk!4v1594063165105!5m2!1sen!2slk" width="320" height="240" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
    </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 style="font-weight:bold;color:#ffd119;">Facebook Fan Page</h4><br>
          <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fweb.facebook.com%2FFlowerriees-flora-1106483016155896%2F&tabs=timeline&width=320&height=240&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=343337676171010" width="320" height="240" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 class="bottom30" style="font-weight:bold;color:#ffd119;">Get in Touch</h4>
          <ul class="getin_touch">
            <li style="font-weight:bold;color:#ffffff;"><i class="icon-telephone114"></i>055-4545794</li>
      <li style="font-weight:bold;color:#ffffff;"><i class="icon-telephone114"></i>071-7197165</li>
      <li style="font-weight:bold;color:#ffffff;"><i class="icon-telephone114"></i>071-1612170</li>
            <li style="font-weight:bold;color:#ffffff;"><a href="javascript:void(0)"><i class="icon-mail-envelope-open"></i>info@furniturePalace.com</a></li>
            <li style="font-weight:bold;color:#ffffff;"><a href="javascript:void(0)"><i class="icon-global"></i>www.furniturePalace.com</a></li>
            <li style="font-weight:bold;color:#ffffff;"><i class="icon-icons74"></i>Main Road,Gampaha</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<!--CopyRight-->
<div class="copyright">
  <div class="copyright_inner">
    <div class="container">
      <div class="row">
        <div class="col-md-7">
          <p style="font-weight:bold;color:#ffffff;">Copyright &copy; 2020 <span>Furniture Palace | Gampaha</span>. All rights reserved.</p>
        </div>
        <div class="col-md-5 text-right">
          <p style="font-weight:bold;color:#ffffff;">Develop by <a href="">SDM Designer</a></p>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="js/jquery-2.1.4.js"></script>
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootsnav.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery-countTo.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/range-Slider.min.js"></script>
<script src="js/owl.carousel.min.js"></script> 
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/selectbox-0.2.min.js"></script>
<script src="js/zelect.js"></script>
<!--Revolution Slider-->
<script src="js/jquery.themepunch.tools.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/revolution.extension.layeranimation.min.js"></script>
<script src="js/revolution.extension.navigation.min.js"></script>
<script src="js/revolution.extension.parallax.min.js"></script>
<script src="js/revolution.extension.slideanims.min.js"></script>
<script src="js/revolution.extension.video.min.js"></script>

<script src="js/neary-by-place.js"></script> 
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script> 
<script src="js/gmaps.js.js"></script>
<script src="js/contact.js"></script>

<script src="js/google-map.js"></script> 


<script src="js/custom.js"></script>
<script src="js/functions.js"></script>
</body>
</html>

